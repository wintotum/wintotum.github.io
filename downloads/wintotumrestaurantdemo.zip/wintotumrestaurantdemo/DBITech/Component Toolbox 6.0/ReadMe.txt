Component Toolbox v6.0

Installation and General Notes

Thank you for purchasing Component Toolbox v6.0. The package includes 60 licensed OCX/ActiveX components (32 bit format only) complete with full on-line help (including a dedicated help file for each component which are found in the "Components" Directory of the product folder). The package also includes sample applications with source code in Visual Basic 6.

For a complete decription of all controls and their description, please see our web site at http://www.dbi-tech.com.

It should be noted that the components have been compiled with the Microsoft Visual C++ 6.0 compiler, which requires the MFC42.DLL and MSVCRT.DLL files. If you do not have these files on your system, they can be downloaded from DBI's web site at http://www.dbi-tech.com.

All of the components have been compiled under Visual C++6.0.  Developers wishing to take advantage of the new functionality found in the Component ToolBox 6.0 must remove references to the old components from their original source, create new instances of the components, and recompile the application(s).

To prevent problems arising from incorporating new versions of older existing controls, it is recommended that any existing application be tested for compatibility with the new version of the control. For example if an existing application uses the old version of ctDate, it is recommended the application be tested with the new version of ctDate before distribution of the new component as part of an install.

If you have any questions, comments, or concerns, please contact DBI Technologies Inc. at: 

DBI Technologies Inc.
E-Mail : dbitech@dbi-tech.com
702-44 Princess Street
Winnipeg,  MB
Canada R3B 1K2

Tel : (204) 985-5770
Fax : (204) 985-5771


